<?php

    class Classified extends DataObject{

        static $db = array(
            "Name" => "Varchar(150)",
            "Description" => "HTMLText",
            "DatePublished" => "Date",
            "URLSegment" => "Varchar(200)",
            "SortOrder" => "Int"

        );

        static $has_one = array(
                "ClassifiedImage" => "Image",
                "ClassifiedHolder" => "ClassifiedHolder"
        );

    }
