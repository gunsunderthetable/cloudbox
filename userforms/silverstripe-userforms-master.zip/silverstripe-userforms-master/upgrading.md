# Upgrade to SilverStripe 3.0 compatible version

## EditableCountryDropdownField

EditableCountryDropdownField is gone since the CountryDropdownField and GeoIP
code has been removed from the SS framework.

