{
    "GRIDFIELD.ERRORINTRANSACTION": "Ett fel uppstod när data hämtades från servern.\nVar god försök igen senare.",
    "UserForms.ADDED_FIELD": "La till nytt fält",
    "UserForms.ADDED_OPTION": "La till alternativ",
    "UserForms.ADDING_FIELD": "Lägger till nytt fält",
    "UserForms.ADDING_OPTION": "Lägger till alternativ",
    "UserForms.ADDING_RULE": "Lägger till regel",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Alla inskickade svar kommer att tas bort permanent. Vill du fortsätta?",
    "UserForms.ERROR_CREATING_FIELD": "Fel när fält skapades",
    "UserForms.ERROR_CREATING_OPTION": "Fel när alternativ skapades",
    "UserForms.HIDE_OPTIONS": "Göm alternativ",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Raderade alternativ",
    "UserForms.SHOW_OPTIONS": "Visa alternativ"
}