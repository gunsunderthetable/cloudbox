{
    "GRIDFIELD.ERRORINTRANSACTION": "Kua puta mai he hapa i te tiki raraunga mai i te tūmau\n Ngāna anō ā muri atu.",
    "UserForms.ADDED_FIELD": "Kua tāpiritia he āpure hou",
    "UserForms.ADDED_OPTION": "Kua tāpiri kōwhiringa",
    "UserForms.ADDING_FIELD": "Tāpiri āpure hou ana",
    "UserForms.ADDING_OPTION": "Tāpiri kōwhiringa ana",
    "UserForms.ADDING_RULE": "Tāpiri ture ana",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Ka muku pūmautia ngā tukunga katoa. Me haere tonu?",
    "UserForms.ERROR_CREATING_FIELD": "Hapa hanga āpure",
    "UserForms.ERROR_CREATING_OPTION": "Hapa hanga kōwhiringa",
    "UserForms.HIDE_OPTIONS": "Hunaia ngā kōwhiringa",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Kua tango kōwhiringa",
    "UserForms.SHOW_OPTIONS": "Whakaatu Kōwhiringa"
}