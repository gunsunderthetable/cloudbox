{
    "GRIDFIELD.ERRORINTRANSACTION": "حدث خطأ أثناء جلب البيانات من الملقم\nيرجى المحاولة مرة أخرى في وقت لاحق.",
    "UserForms.ADDED_FIELD": "أضيف حقل جديد",
    "UserForms.ADDED_OPTION": "الخيار المضاف",
    "UserForms.ADDING_FIELD": "إضافة حقل جديد",
    "UserForms.ADDING_OPTION": "إضافة خيار",
    "UserForms.ADDING_RULE": "إضافة قاعدة",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "ستتم إزالة جميع الطلبات المقدمة بشكل دائم. المتابعة؟",
    "UserForms.ERROR_CREATING_FIELD": "خطأ في إنشاء الحقل",
    "UserForms.ERROR_CREATING_OPTION": "خطأ في إنشاء الخيار",
    "UserForms.HIDE_OPTIONS": "إخفاء الخيارات",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "تمت إزالة الخيار",
    "UserForms.SHOW_OPTIONS": "إظهار الخيارات"
}