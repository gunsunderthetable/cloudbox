{
    "GRIDFIELD.ERRORINTRANSACTION": "An error occured while fetching data from the server\n Please try again later.",
    "UserForms.ADDED_FIELD": "Added new field",
    "UserForms.ADDED_OPTION": "Added option",
    "UserForms.ADDING_FIELD": "Adding new field",
    "UserForms.ADDING_OPTION": "Adding option",
    "UserForms.ADDING_RULE": "Adding rule",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "All submissions will be permanently removed. Continue?",
    "UserForms.ERROR_CREATING_FIELD": "Error creating field",
    "UserForms.ERROR_CREATING_OPTION": "Error creating option",
    "UserForms.HIDE_OPTIONS": "Hide options",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Removed option",
    "UserForms.SHOW_OPTIONS": "Show options"
}