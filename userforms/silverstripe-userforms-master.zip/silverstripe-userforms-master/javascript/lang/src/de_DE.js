{
    "GRIDFIELD.ERRORINTRANSACTION": "Ein Fehler ist beim Laden der Daten aufgetreten.\nBitte versuchen Sie es später nochmal.",
    "UserForms.ADDED_FIELD": "Neues Feld hinzugefügt",
    "UserForms.ADDED_OPTION": "Option hinzugefügt",
    "UserForms.ADDING_FIELD": "Neues Feld hinzugefügt",
    "UserForms.ADDING_OPTION": "Füge Option hinzu",
    "UserForms.ADDING_RULE": "Füge Regel hinzu",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Alle Einsendungen werden dauerhaft gelöscht. Wirklich fortfahren?",
    "UserForms.ERROR_CREATING_FIELD": "Fehler beim erstellen des Feldes",
    "UserForms.ERROR_CREATING_OPTION": "Fehler beim erstellen der Option",
    "UserForms.HIDE_OPTIONS": "Optionen verbergen",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Option entfernt",
    "UserForms.SHOW_OPTIONS": "Optionen anzeigen"
}