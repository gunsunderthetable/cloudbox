{
    "GRIDFIELD.ERRORINTRANSACTION": "Nastala chyba pri získavaní dát zo servera.\nProsím, skúste to neskôr.",
    "UserForms.ADDED_FIELD": "Nové políčko pridané",
    "UserForms.ADDED_OPTION": "Voľba/možnosť pridaná",
    "UserForms.ADDING_FIELD": "Pridávanie nového políčka",
    "UserForms.ADDING_OPTION": "Pridávanie voľby/možnosti",
    "UserForms.ADDING_RULE": "Pravidlo priadné",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Všetky podané formuláre budú permanentne odstránené. Pokračovať?",
    "UserForms.ERROR_CREATING_FIELD": "Nastala chyba pri vytváraní poľa",
    "UserForms.ERROR_CREATING_OPTION": "Nastala chyba pri vytváraní voľby/možnosti",
    "UserForms.HIDE_OPTIONS": "Skryť možnosti",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Voľba/možnosť odstránená",
    "UserForms.SHOW_OPTIONS": "Zobraziť možnosti"
}