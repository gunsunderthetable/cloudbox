{
    "GRIDFIELD.ERRORINTRANSACTION": "Ocurrió un error mientras se obtenían datos desde el servidor\n Por favor, más tarde, inténtelo nuevamente.",
    "UserForms.ADDED_FIELD": "Nuevo campo agregado",
    "UserForms.ADDED_OPTION": "Opción agregada",
    "UserForms.ADDING_FIELD": "Agregar un nuevo campo",
    "UserForms.ADDING_OPTION": "Agregar opción",
    "UserForms.ADDING_RULE": "Agregar regla",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Se eliminarán todos los envíos. ¿Continuar?",
    "UserForms.ERROR_CREATING_FIELD": "Error al crear campo",
    "UserForms.ERROR_CREATING_OPTION": "Error al crear opción",
    "UserForms.HIDE_OPTIONS": "Ocultar opciones",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Opción eliminada",
    "UserForms.SHOW_OPTIONS": "Mostrar opciones"
}